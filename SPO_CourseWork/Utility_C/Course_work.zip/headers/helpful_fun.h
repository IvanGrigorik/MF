//
// Created by sifi on 5/8/22.
//

#ifndef C_HELPFUL_FUN_H
#define C_HELPFUL_FUN_H

#include "../headers/parse_input.h"
#include "../headers/structures.h"
#include "../headers/file_work.h"
#include "../headers/testing.h"

void check_flags(flags_t flags);

void output_help();

#endif //C_HELPFUL_FUN_H
