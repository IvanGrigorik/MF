//
// Created by sifi on 18.04.22.
//

#ifndef UTILITY_C_HASHING_H
#define UTILITY_C_HASHING_H

#endif //UTILITY_C_HASHING_H

#include <openssl/md5.h>
#include <stdio.h>
#include <malloc.h>

char *md5_to_string(unsigned char *md);